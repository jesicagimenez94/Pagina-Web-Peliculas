
<!DOCTYPE html>
<html>
<head>
<title>
  peliculas
</title>
  <meta charset="utf-8">
    <link rel="Shortcut Icon" type="image/x-icon" href="assets/icons/logoo.png" />
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
   <link rel="stylesheet" href="css/style.css">
   <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  


</head>


 <script>
      $(document).ready(function()
      {
         $("#mostrarmodal").modal("show");
      });
    </script>

<style>

    body{
        background-image: url(assets/img/cargando.gif);
        background-size:cover;
        background-repeat: no-repeat;
        background-attachment:fixed;
    }
</style>


<META HTTP-EQUIV="REFRESH" CONTENT="4;URL=index.php"> 



</html>
<?php
        $conexion=mysqli_connect("localhost","root","","parcialjesi") or
        die("Problemas con la conexión");
        
     
   ?>